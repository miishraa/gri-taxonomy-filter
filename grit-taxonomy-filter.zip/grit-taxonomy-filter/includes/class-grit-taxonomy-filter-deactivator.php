<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://grittechnologies.com
 * @since      1.0.0
 *
 * @package    Grit_Taxonomy_Filter
 * @subpackage Grit_Taxonomy_Filter/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Grit_Taxonomy_Filter
 * @subpackage Grit_Taxonomy_Filter/includes
 * @author     Mrityunjay Kumar
 */
class Grit_Taxonomy_Filter_Deactivator {

	/**
	 * Deactivate if not required or compatible
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}

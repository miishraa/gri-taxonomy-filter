===GRIT Taxonomy Filter ===

Contributors:      Mrityunjay
Plugin Name:       GRIT Taxonomy Filter
Plugin URI:        https://grittechnologies.com/plugins
Tags:              Taxonomy Filter, Category Filter, Custom Categories filter
Author URI:        https://profiles.wordpress.org/mrityunjay/
Author:            Mrityunjay Kumar
Donate link:       paypal.me/miishraa
Requires at least: 3.5
Requires PHP: 5.6
Tested up to:      5.4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Version:          1.0
Stable tag: trunk

== Description ==
This plugin can be used to filter taxonomies of custom post type as well as default categories of wordpress upto  depth 3. Please note that taxonomy of upto depth 3 is necessary for this
to work. Ex : Country -> State -> Cities (Category->Sub category-> Sub sub-category) . Use shortcode [GRITFILTER] in your posts or pages to use it.

== Installation ==
Install using either ftp or using dashboard/plugins/add new options in wordpress dashboard. After upload, go to settings, add taxonomy name and post type. If you want to use with default categories and posts , simply add 'post' and 'category'

== Upgrade Notice ==
Future upgrade may enable it to use with woocommerce

== Screenshots ==
1. Add taxonomy and post type name
2. Front page view

== Changelog ==
 No changelog since it is first version

== Frequently Asked Questions ==
How to use this?
Simply install and use given shortcode in your post , pages or templates.

Will it work with default categories of default posts?
Yes

Will it work with custom post types?
Yes


== Donations ==

If you liked this plugin, Please donate.


